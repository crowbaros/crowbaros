# CrowbarOS brand-kit scope

<!-- impeccable:product-schema 1 -->

## Platform

web

The HTML in this kit is a local review tool for Linux desktop design concepts, not the operating system implementation. Native implementation remains Niri and Quickshell as specified in the source plan.

## Users and purpose

The source plan serves everyday desktop users, writers, creatives and makers. This branding round explicitly adds appeal for technically fluent Linux users and hackers while preserving approachable proportional UI typography.

## Brand commitments

The user selected CrowbarOS, Nullkeel's five exact colors, and Rookslash's engraved crow. Prior approved references are ../round-02-dark/assets/05-rookslash.png and ../round-03-cyan-crow/cyan-crow-name-studies.png. This task completes a brand kit with logos, wallpapers and desktop mockups.

## Capabilities and constraints

The source of product truth is ../../community_foss_distro_plan.md. Five default apps: Zen Browser, Nautilus Files, Ghostty, Studio Settings and Bazaar. Horizontal scrolling windows, Zen Mode hiding bar/dock, three luminance modes, neutral Studio Mode. No bundled AI. No telemetry. Community-built with a founder-steward governance model. All mockup data and windows are illustrative; they do not represent a shipped OS.

## Open decisions

Release timing, asset licensing and trademark clearance are outside this kit. No domain registration or OS installation is performed.
